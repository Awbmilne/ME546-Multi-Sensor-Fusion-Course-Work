************************************************
About your download
************************************************
This download contains a complete set of approved logos for print and digital publishing for the entity specified by the folder name. You can save this folder to a permanent location on your hard drive, server, or SharePoint site.
All logos included in this download are approved versions. The logos include the required clear space. You may not alter the logos in any way. 
For complete guidelines on usage, go to https://uwaterloo.ca/brand-guidelines/visual-identity/logo-system.
************************************************
File types
************************************************
EPS
Use .eps (encapsulated postscript) files for design work in software such as the Adobe Creative Suite, large print projects, distribution to vendors for merchandising (for example, embroidery on a shirt). You can also insert .eps files in MS Office files like Word and PowerPoint. 
.eps files contain data that programs use to re-render the image and retain the vector data from the native source. This means that they can scale to any size without a reduction in quality.
Do not use the .eps files to create your own version of the logo. All approved versions are provided in this download.
JPG
Use .jpg files for design work in MS Office projects, digital publishing and small in-house print projects (e.g. a luncheon announcement for a bulletin board). 
.jpg files are compressed/flat lossy versions of the logo. These image files can be made smaller, but cannot be made larger as quality would be significantly reduced.  
PNG
Use .png files for digital publishing such as PowerPoint presentations, display screens, websites and e-newletters. 
.png files are bitmapped images with lossless data compression. The .png format replaces the .gif format and has enhanced display and performance properties. All of the .png files have a transparent background. .png  files can be made smaller, but cannot be made larger as quality would be significantly reduced.  
************************************************
File name key
************************************************
Horiz Ð the shield appears beside the work mark horizontally.
Vert Ð the word mark and the shield are stacked vertically. 
Bk Ð all black version
Rev Ð white logo on a black background
CMYK Ð CMYK is theÊstandardÊsubtractive colour model used inÊoffset printing for full-colorÊdocuments.
PMS Ð the Pantone Matching System is used by the print industry to print spot colours.
RGB Ð RGB is anÊadditiveÊcolour modelÊused for electronic systems.
Examples:
UniversityOfWaterloo_logo_horiz_bk.eps indicates that the logo is the University of Waterloo horizontal logo in black.
UniversityOfWaterloo_logo_horiz_cmyk.eps indicates that the logo is the University of Waterloo horizontal logo in CMYK colour.

